Author: Cade Parkison
University of Utah
Machine Learning


To run the tests to generate all data, just run the file run.sh.

This calls the python file test.py to call the relevant functions.

The files lms.py, and ensemble.py are the respective algorithms and related funtions.

The two Jupyter notebooks, ensemble.ipynb and lms.ipynb were used to implement and test the algorithms. These files are a good place to see my attempted work, despite incomplete results. 

Unfortunately, I was unable to achieve good results on all parts of this assignment. An issue was that each test of bagging and random forest took many hours to run.
I had trouble debugging in the time allowed, but I believe I have implemented the required algoritms correctly, or mostly correct. 