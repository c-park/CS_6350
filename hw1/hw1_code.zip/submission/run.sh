#!/bin/bash
python testing.py