#!/bin/sh
python test.py